function [fields,allFields] = fieldDetection2D(map,varargin)
% basic field detection mechanism written by Oyvind (like he uses in his
% object vector cells paper)
% but added different way of finding the thresholds for field detection
% a(meaning where it will draw the contours) and field inclusion (meaning
% how high the peak firing rate of the field must be for it to be included)

% S = dManDe.Settings();
inp = inputParser();
inp.addParameter('median',[])
inp.addParameter('std',[]);
inp.addParameter('minRate',2); % minimum peak rate (Hz) for a field to be included
inp.addParameter('minBin',16); % minimum size (number of pixles) of fields to be included

inp.addParameter('doPlot',true);
inp.addParameter('addMap',true);
inp.addParameter('ax',[]);
inp.addParameter('r',0.5);
inp.parse(varargin{:});
inp.KeepUnmatched = true;
p = inp.Results;

%% ged thresholds for field detection and inclusion 
% thresholds derived from standard deviation and median of the map

if isempty(p.median)
    mapMedian = nanmedian(map(:));
else
    mapMedian = p.median;
end
if isempty(p.std)
    mapStd = nanstd(map(:));
else
    mapStd = p.std;
end

fieldDetectionThresh = mapMedian + mapStd;
fieldInclusionThresh = mapMedian + 2*mapStd;



%% find the fields with countour

% Zeropad to avoid border effects
map(isnan(map)) = 0;
padsize = 3;
padadd = padsize - 1;
mapP = padarray(map,[padsize padsize],0,'both');
mapP(isnan(mapP)) = 0;

% make 1d map
mapP1d = mapP(:);
maxmap = max(mapP1d);

% Get  contourmatrixs
[X,Y] = meshgrid(1:size(mapP,2),1:size(mapP,1));

contourFig = figure('visible', 'on');
[~,h] = contour(X,Y,mapP);

if fieldDetectionThresh < maxmap
    set(h, 'LevelList', linspace(fieldDetectionThresh,maxmap,20));
    set(h,'ShowText','on','TextStep',get(h,'LevelStep')*2)
    x = reshape(X,1,numel(X));
    y = reshape(Y,1,numel(Y));
    cm = get(h,'ContourMatrix');
    index_start = 2;
    index_end = cm(2,1)+1;
    IN = inpolygon(x,y,cm(1,index_start:index_end),cm(2,index_start:index_end));
    for i=2:numel(get(h,'LevelList'))
        index_start = index_end + 2;
        index_end = index_start + cm(2,index_start-1) - 1;
        tmp = inpolygon(x,y,cm(1,index_start:index_end),cm(2,index_start:index_end));
        IN = IN | tmp;
    end
    %close(contourFig)
else
    IN = false(1,numel(h.XData));
end

%%
% Define matrix of fields and find connected regions
nap = mapP1d'.*IN;
nap = reshape(nap,size(mapP));
CC = bwconncomp(nap);

% Remove fields that have fewer pixels or lower peak rate than threshold
H = CC.PixelIdxList;
H = H(cellfun(@(x) length(x) >= p.minBin, H));
H = H(cellfun(@(x) max(nap(x)) >= fieldInclusionThresh, H));

% Remake map with fields all above threshold
fieldMap = zeros(size(mapP1d,1),1);

for i = 1:size(H,2)
    fieldMap(H{1, i}) = mapP1d(H{1, i});
end

fieldMap = reshape(fieldMap,size(mapP));

% Remove zeropad
fieldMap(1:padsize,:) = [];
fieldMap(end-padadd:end,:) = [];
fieldMap(:,1:padsize) = [];
fieldMap(:,end-padadd:end) = [];

% Define connected regions and get centroids
CC = bwconncomp(fieldMap);
S = regionprops(CC,'centroid');


%%  create output

fields = struct('pixelIdxList',{},'incAbThresh',{},'subX',{},'subY',{},'map',{},...
    'centroid',{},'xScore',{},'yScore',{});
for i = 1:CC.NumObjects
    fields(i).pixelIdxList = CC.PixelIdxList{i};
    fields(i).thresh = fieldDetectionThresh;
    
    [sX,sY] = ind2sub(size(map),CC.PixelIdxList{i});
    fields(i).subX = sX;
    fields(i).subY = sY;
    
    tmpFieldMap = zeros(size(fieldMap));
    tmpFieldMap(sX,sY) = fieldMap(sX,sY);
    fields(i).map = tmpFieldMap;
    
    fields(i).incAbThresh = (max(tmpFieldMap)-fieldDetectionThresh)/fieldDetectionThresh;
    fields(i).centroid = S(i).Centroid;
end


if ~p.addMap
    for i = 1:numel(fields)
        fields(i).map = [];
    end
end


allFields = struct('map',[],'numFields',[],...
    'xScore',[],'yScore',[]);
if p.addMap
    allFields.map = fieldMap;
end
allFields.numFields = numel(fields);
[xScore,yScore] = getScores(fieldMap,p.doPlot,p.ax,p.r);
allFields.xScore = xScore;
allFields.yScore = yScore;

allFields.mapMedian = mapMedian;
allFields.mapStd = mapStd;


% Plot map with fields (if doPlot)
if p.doPlot
    if isempty(p.ax)
        ax1 = subplot(2,2,1); 
        ax2 = subplot(2,2,2);
    else
        ax1 = p.ax(1);
        ax2 = p.ax(2);
    end
    imagesc(ax1,map);
    axis(ax1,'square','off','xy');

    imagesc(ax2,fieldMap);
    axis(ax2,'square','off','xy');

    colormap('jet');
end

end

%%
function [xScore,yScore] = getScoresNT(map,doPlot,ax)
    
    map = map/max(max(map));
    
    xDim = size(map,2);
    yDim = size(map,1);
    r = 1;
    
    % map operations
    mapOnes = zeros(size(map));
    mapOnes(map > 1) = 1;
    nMap = numel(map);
    
    % x dim rectangle overlay
    scores = nan(5,yDim-5);
    for i = 1:5
        for j = 1:yDim-i
            dummyMap = zeros(size(map));
            dummyMap(j:j+i-1,1:xDim) = true;
            
            inBarIdx = find(dummyMap);
            inBarMean = mean(map(inBarIdx));
            
            outBarIdx = find(~dummyMap);
            outBarMean = mean(map(outBarIdx));

            scores(i,j) = inBarMean - r*outBarMean;
        end
    end
    [maxJ,idx] = max(scores);
    [maxMS,imJ] = max(maxJ);
    imI = idx(imJ);
    
    xScore.sc = maxMS;
    xScore.recWidth = imI;
    xScore.pxlIdx = imJ;
    xdMap = zeros(size(map));
    xdMap(imJ:imJ+imI-1,:) = 1;
    xScore.dMap = xdMap;
    
    [row,~] = find(xdMap,1);
    xScore.dist = row/yDim;
    
    % y dim rectangle overlay
    scores = nan(5,yDim-5);
    for i = 1:5
        for j = 1:xDim-i
            dummyMap = zeros(size(map));
            dummyMap(1:yDim,j:j+i-1) = 1;
            
            inBarIdx = find(dummyMap);
            inBarMean = mean(map(inBarIdx));
            
            outBarIdx = find(~dummyMap);
            outBarMean = mean(map(outBarIdx));

            scores(i,j) = inBarMean - r*outBarMean;
        end
    end
    [maxJ,idx] = max(scores);
    [maxMS,imJ] = max(maxJ);
    imI = idx(imJ);
    
    yScore.sc = maxMS;
    yScore.recWidth = imI;
    yScore.pxlIdx = imJ;
    ydMap = zeros(size(map));
    ydMap(:,imJ:imJ+imI-1) = 1;
    yScore.dMap = ydMap;
    
    [~,col] = find(ydMap,1);
    yScore.dist = col/xDim;
    
            
    if doPlot
        if isempty(ax)
            ax1 = subplot(2,2,3);
            ax2 = subplot(2,2,4);
        else
            ax1 = ax(3);
            ax2 = ax(4);
        end
        imagesc(ax1,xdMap);
        axis(ax1,'square','off','xy');
%         title('X dimension')
        
        imagesc(ax2,ydMap);
        axis(ax2,'square','off','xy');
%         title('Y dimension')
    end
end

%% 
function [xScore,yScore] = getScores_4scores(map)
    % thresholds
    
    thrP = 0.8;
%     thrR = 0.1; % divided by extent
    thrE = 0.5;
    thrN = 0.7;
    thrS = 0.7;

    % xDim
    xDim = size(map,2);
    xParallel = nan(xDim,1);
    xExtent = nan(xDim,1);
    % yDim
    yDim = size(map,1);
    yParallel = nan(yDim,1);
    yExtent = nan(yDim,1);
    
    
    % find xParallel (how parallel the field is to the x wall)
    for k = 2:xDim-1
        cCol = map(:,k);
        props = regionprops(true(size(cCol)),cCol,'WeightedCentroid');
        xParallel(k) = props.WeightedCentroid(2);
        tmpExtent = find(logical([0;cCol;0]),1):find(logical([0;cCol;0]),1,'last');
%         tmpExtent = diff(find(diff(logical([0;cCol;0]))~=0));
        if ~isempty(tmpExtent)
            xExtent(k) = numel(tmpExtent)/yDim;
%             xExtent(k) = max(tmpExtent(1:2:end))/yDim;
        end
    end
    
    % find b (y achsenabschnitt und steigung) by fitting a lin regression
    fitX = [ones(1,xDim);1:xDim]';
    vNan = isnan(xParallel);
    fitX(vNan,:) = [];
    xParallel(vNan,:) = [];
    b = fitX\xParallel;
    
    % find R2 (goodness of fit)
    xCalc = fitX*b;
    v1 = [fitX(1,2),b(1)+fitX(1,2)*b(2),0];
    v2 = [fitX(end,2),b(1)+fitX(end,2)*b(2),0];
    for i = 1:numel(xParallel)
        pt = [fitX(i,2),xParallel(i,:),0];
        dm(i) = point_to_line_matlab(pt, v1, v2);
        d(i) = point_to_line(pt, b(1), b(2));
    end
%     Rsq2 = 1 - sum((xParallel - xCalc).^2)/sum((xParallel - mean(xParallel)).^2);
    sprd = 1-median(d)/3.2;
    sprd(sprd<0) = 0;
    % find narrowness of field
    xExtent(~(xExtent>0)) = [];
    
    xScore.closeToWall = abs((b(1)-(yDim/2))/(yDim/2)); % closeness to wall score: from 0-1
    xScore.ptw = abs(1-abs(b(2))); % parralell to wall score: from 0-1
%     xScore.rsq = Rsq2;
    xScore.ext = numel(xParallel)/xDim; % extent of coverage: from 0-1
    xScore.nrw = 1-median(xExtent);
    xScore.sprd = sprd;
    
    if xScore.ptw>thrP && xScore.sprd>thrS && xScore.ext>thrE && xScore.nrw>thrN
        xScore.bc = true;
    else
        xScore.bc = false;
    end
    gcf;
    hold on
    subplot(2,2,3);
    plot(fitX(:,2),xParallel,'k*');
    hold on
    plot(fitX(:,2),xCalc)
    ax = gca;
    ax.XLim = [0,32];
    ax.YLim = [0,32];
    title('X dimension')
  
    

    for k = 2:yDim-1
        cCol = map(k,:)';
        props = regionprops(true(size(cCol)),cCol,'WeightedCentroid');
        yParallel(k) = props.WeightedCentroid(2);
        tmpExtent = find(logical([0;cCol;0]),1):find(logical([0;cCol;0]),1,'last');
%         tmpExtent = diff(find(diff(logical([0;cCol;0]))~=0));
        if ~isempty(tmpExtent)
            yExtent(k) = numel(tmpExtent)/xDim;
%             yExtent(k) = max(tmpExtent(1:2:end))/xDim;
        end
        
    end
    
    % find b (y achsenabschnitt und steigung) by fitting a lin regression
    fitX = [ones(1,yDim);1:yDim]';
    vNan = isnan(yParallel);
    fitX(vNan,:) = [];
    yParallel(vNan,:) = [];
    b = fitX\yParallel;

    % find R2 (goodness of fit)
    yCalc = fitX*b;
    v1 = [fitX(1,2),b(1)+fitX(1,2)*b(2),0];
    v2 = [fitX(end,2),b(1)+fitX(end,2)*b(2),0];
    d = [];
    for i = 1:numel(yParallel)
        pt = [fitX(i,2),yParallel(i,:),0];
        dm(i) = point_to_line_matlab(pt, v1, v2);
        d(i) = point_to_line(pt, b(1), b(2));
    end
%     Rsq2 = 1 - sum((yParallel - yCalc).^2)/sum((yParallel - mean(yParallel)).^2);
    sprd = 1-mean(d)/3.2;
    sprd(sprd<0) = 0;
    ySprd = 1-(mean(abs(yParallel-yCalc))/5);
    
     % find narrowness of field
    yExtent(~(yExtent>0)) = [];

    yScore.closeToWall = abs((b(1)-(xDim/2))/(xDim/2)); % closeness to wall score: from 0-1
    yScore.ptw = abs(1-abs(b(2))); % parralell to wall score: from 0-1
%     yScore.rsq = Rsq2;
    yScore.ext = numel(yParallel)/yDim; % extent of coverage: from 0-1
    yScore.nrw = 1-mean(yExtent);
    yScore.sprd = sprd;
    if yScore.ptw>thrP && yScore.sprd>thrS && yScore.ext>thrE && yScore.nrw>thrN
        yScore.bc = true;
    else
        yScore.bc = false;
    end
    
    
    subplot(2,2,4);
    hold on
    plot(fitX(:,2),yParallel,'k*');
    hold on
    plot(fitX(:,2),yCalc)
    ax = gca;
    ax.XLim = [0,32];
    ax.YLim = [0,32];
    title('Y dimension')
end






%% 

function [xScore,yScore] = getScoresPxl(map) 
    
    
    % zeropad map
    mapP = padarray(map,[1 1],0,'both');
    yDim = size(map,2);
    xDim = size(mapP,1);  
    
    % neighbors
    xNeighbors = nan(xDim,1);
    yNeighbors = nan(yDim,1);
    
    diagonal1 = nan(xDim,1);
    diagonal2 = nan(xDim,1); 
    
    % find neighbors in each collumn in x dimention
    for k = 1:xDim
        cCol = logical(mapP(k,:)');
        scIdx = find(diff(cCol)); % find state changes
        xNeighbors(k) = sum(scIdx(2:2:end) - scIdx(1:2:end));
    end
    
    % find neighbors in each collumn in y dimention
    for k = 1:yDim
        cCol = logical(mapP(:,k));
        scIdx = find(diff(cCol)); % find state changes
        yNeighbors(k) = sum(scIdx(2:2:end) - scIdx(1:2:end));
    end
    
    % find neighbors in diagonal 1 and 2 
    for k = 1:xDim-1
        % diagonal 1
        cRow = logical([mapP(k,:),0]);
        nRow = logical([0,mapP(k+1,:)]); % next row - shifted to right
        vDiff = logical(abs(diff([cRow;nRow],1))); % find the difference between the rows
        diagonal1(k) = numel(find(~vDiff & cRow)); % find where there is no difference but there are values in current row
        
        % dagonal 2
        cRow = logical([0,mapP(k,:)]);
        nRow = logical([mapP(k+1,:),0]); % next row - shifted to right
        vDiff = logical(abs(diff([cRow;nRow],1))); % find the difference between the rows
        diagonal2(k) = numel(find(~vDiff & cRow)); % find where there is no difference but there are values in current row
    end
    
    
    xScore = abs(nansum(xNeighbors) - max(nansum(diagonal1),nansum(diagonal2)))/nansum(xNeighbors); 
    yScore = abs(nansum(yNeighbors) - max(nansum(diagonal1),nansum(diagonal2)))/nansum(yNeighbors);

end


function d = point_to_line_matlab(pt, v1, v2)
  a = v1 - v2;
  b = pt - v2;
  d = norm(cross(a,b)) / norm(a);
end

function d = point_to_line(pt, a, b)
  d = abs(pt(2)-(a+b*pt(1)))*cos(atan(b));
end

 



